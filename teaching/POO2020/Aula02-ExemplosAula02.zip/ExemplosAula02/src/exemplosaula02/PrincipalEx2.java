/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula02;

/**
 *
 * @author danil
 */
public class PrincipalEx2 {
     public static void main(String[] args) {
         AlunoAcademia a1 = new AlunoAcademia();
         a1.setNome("Danilo");
         a1.setIdade(39);
         a1.setPeso(95);
         a1.setAltura(1.77f);
         
         if (a1.maior())
             System.out.println("MAIOR");
         else System.out.println("MENOR");
         
         System.out.println("IMC de "+a1.getNome()+" e´ "+a1.IMC());         
     }
}

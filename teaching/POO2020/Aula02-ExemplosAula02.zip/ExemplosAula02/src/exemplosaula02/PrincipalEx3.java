/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula02;

/**
 *
 * @author danil
 */
public class PrincipalEx3 {

    public static void main(String[] args) {
        Conta c1 = new Conta();
        c1.setNome("Danilo");
        c1.setNumero("111");

        System.out.println("Saldo Atual: " + c1.getSaldo());
        c1.depositar(100);
        System.out.println("Saldo Atual: " + c1.getSaldo());
        c1.sacar(50);
        System.out.println("Saldo Atual: " + c1.getSaldo());
        c1.sacar(150);
        System.out.println("Saldo Atual: " + c1.getSaldo());

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula02;

/**
 *
 * @author danilo
 */
public class PrincipalEx1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("INICIO");

        Aluno a1 = new Aluno();
        a1.setT1(5);
        a1.setT2(6);
        a1.setN1(8);
        a1.setN2(8);

        System.out.println("Media: " + a1.media());
        if (a1.aprovado()) {
            System.out.println("APROVADO");
        } else {
            System.out.println("REPROVADO");
        }
        System.out.println("Aprovado: " + a1.aprovado());

        Aluno a2 = new Aluno();
        a2.setT1(3);
        a2.setT2(4);
        a2.setN1(2);
        a2.setN2(1);
        System.out.println("Media: " + a2.media());
        if (a2.aprovado()) {
            System.out.println("APROVADO");
        } else {
            System.out.println("REPROVADO");
        }
        System.out.println("Aprovado: " + a2.aprovado());

    }

}

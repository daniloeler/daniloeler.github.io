/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula02;

/**
 *
 * @author danil
 */
public class Aluno {
    private String ra;
    private String nome;
    private float t1;
    private float t2;
    private float n1;
    private float n2;
    
    public float media(){
        float media = (t1+t2+n1+n2)/4.0f;
        return media;
    }
    
    public boolean aprovado(){
        if (media() >=5)
            return true;
        return false;
    }
    
    public void setT1(float t1){
        this.t1 = t1;
    }
    
    public void setT2(float t2){
        this.t2 = t2;
    }
    
    public void setN1(float n1){
        this.n1 = n1;
    }
    
    public void setN2(float n2){
        this.n2 = n2;
    }
    
}

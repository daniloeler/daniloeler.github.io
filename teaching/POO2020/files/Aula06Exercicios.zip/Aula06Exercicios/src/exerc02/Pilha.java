/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Pilha extends ED {

    protected int topo;

    public Pilha(int max) {
        super(max);
        topo = 0;
    }

    @Override
    public void adicionar(int elem) {
        if (topo < max) {
            vetor[topo] = elem;
            topo++;
        }
    }

    @Override
    public int remover() {
        if (topo > 0) {
            topo--;
            int elem = vetor[topo];            
            return elem;
        }
        return -1;
    }

}

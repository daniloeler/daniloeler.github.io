/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Principal {

    public static void main(String[] args) {
        //ED estrutura = new Pilha(10); //uma pilha com 10 posições
        //ED estrutura = new Fila(5); //uma fila com 10 posições
        ED estrutura = new FilaPrioridade(5); //uma fila com prioridade com 10 posições
        estrutura.adicionar(10);
        estrutura.adicionar(5);
        estrutura.adicionar(7);
        estrutura.adicionar(2);
        estrutura.adicionar(4);       
        System.out.println(estrutura.remover());
        System.out.println(estrutura.remover());
        System.out.println(estrutura.remover());
        System.out.println(estrutura.remover());
        System.out.println(estrutura.remover());
        estrutura.adicionar(14);       
        estrutura.adicionar(4);       
        estrutura.adicionar(334);       
        System.out.println(estrutura.remover());
        System.out.println(estrutura.remover());
        System.out.println(estrutura.remover());
        System.out.println(estrutura.remover());
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class FilaPrioridade extends Fila {

    public FilaPrioridade(int max) {
        super(max);
    }

    @Override
    public void adicionar(int elem) {
        if (numElem < max) {
            int i = inicio;
            int cont = 0;
            while (vetor[i] < elem && cont < numElem) {
                i = (i + 1) % max;
                cont++;
            }            
            int auxNumElem = numElem;
            int pos = (inicio + auxNumElem)%max;
            while (i!=pos){
                vetor[pos] = vetor[(inicio + auxNumElem - 1)%max];
                auxNumElem--;
                pos = (inicio + auxNumElem)%max;
            }
            vetor[i] = elem;
            numElem++;
        }
    }
}

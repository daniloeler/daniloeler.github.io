/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public abstract class ED {
    protected int vetor[];
    protected int max;
    public ED(int max){
        this.max = max;
        vetor = new int[max];
    }
    public abstract void adicionar(int elem);
    public abstract int remover();
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Fila extends ED {

    protected int inicio;
    protected int numElem;

    public Fila(int max) {
        super(max);
        inicio = numElem = 0;
    }

    @Override
    public void adicionar(int elem) {
        if (numElem < max) {
            int pos = (inicio + numElem) % max;
            vetor[pos] = elem;
            numElem++;
        }
    }

    @Override
    public int remover() {
        if (numElem > 0) {
            int elem = vetor[inicio];
            inicio = (inicio + 1) % max;
            numElem--;
            return elem;
        }
        return -1;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc01;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Principal {
    public static void main(String[] args) {
        Pessoa p = new Pessoa("Pessoa 1", 50);
        p.addContato(new Email("pessoa1@hotmail.com"));
        p.addContato(new Email("pessoa1@gmail.com"));
        p.addContato(new Telefone("32456125"));
        p.addContato(new Telefone("994754564"));
       // p.exibir();
       // System.out.println("Possui Email: "+p.possuiEmail());
       // System.out.println("Possui Telefone: "+p.possuiTelefone());
        
        Pessoa p1 = new Pessoa("Pessoa sem Email", 50);
        p1.addContato(new Telefone("12345678"));
        p1.addContato(new Telefone("19999"));
        
        Pessoa p2 = new Pessoa("Pessoa sem Telefone", 50);
        p2.addContato(new Email("asdfasf@hotmai.com"));
        
        Pessoa p3 = new Pessoa("Pessoa sem contato", 50);
        
        Agenda ag = new Agenda("Danilo", 100);
        ag.addPessoa(p);
        ag.addPessoa(p1);
        ag.addPessoa(p2);
        ag.addPessoa(p3);
        System.out.println("////");
        ag.exibirTodasPessoas();
        System.out.println("////");
        ag.exibirContatosPessoa("Pessoa sem Telefone");
        System.out.println("////");
        ag.exibirPessoaComEmail();
        System.out.println("////");
        ag.recuperarPessoaPorEmail("asdfasf@hotmai.com");
        System.out.println("////");
        ag.recuperarPessoaPorTelefone("19999");
        System.out.println("////");
        ag.addContato("Pessoa sem contato", new Email("asdfasfsd@hotmail.com"));
        System.out.println("////");
        ag.exibirTodasPessoas();
        System.out.println("////");
        ag.exibirPessoaComEmail();
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc01;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Pessoa {

    protected String nome;
    protected Contato contatos[];
    protected int max;
    protected int cont;

    public Pessoa(String nome, int max) {
        this.nome = nome;
        this.max = max;
        contatos = new Contato[max];
        cont=0;
    }

    public void addContato(Contato c) {
        if (cont < max) {
            contatos[cont] = c;
            cont++;
        }
    }

    public Contato[] getContatos() {
        return contatos;
    }

    public Contato[] getContatos(String tipo) {
        int contC = 0;
        for (int i = 0; i < cont; i++) {
            if (contatos[i].getTipo().equals(tipo)) {
                contC++;
            }
        }
        if (contC > 0) {
            Contato vet[] = new Contato[contC];
            int contNovo = 0;
            for (int i = 0; i < cont; i++) {
                if (contatos[i].getTipo().equals(tipo)) {
                    vet[contNovo] = contatos[i];
                    contNovo++;
                }
            }
            return vet;
        }
        return null;
    }

    public boolean possuiEmail() {
        for (int i = 0; i < cont; i++) {
            if (contatos[i].getTipo().equals("Email")) {
                return true;
            }
        }
        return false;
    }
    
    public boolean possuiTelefone() {
        for (int i = 0; i < cont; i++) {
            if (contatos[i].getTipo().equals("Telefone")) {
                return true;
            }
        }
        return false;
    }
    
    public void exibir(){
        System.out.println("Nome: "+nome);
        for(int i=0; i<cont; i++){
            contatos[i].exibir();
        }
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc01;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Agenda {
    private String proprietario;
    private Pessoa pessoas[];
    private int max;
    private int cont;
    public Agenda(String proprietario, int max){
        this.proprietario = proprietario;
        this.max = max;        
        pessoas = new Pessoa[max];
        int cont = 0;
    }
    
    public void addPessoa(Pessoa p){
        if (cont < max){
            pessoas[cont] = p;
            cont++;
        }
    }
    
    public Pessoa buscarPessoa(String nome){
        for(int i=0; i<cont; i++){
            if (pessoas[i].getNome().equals(nome)){
                return pessoas[i];
            }
        }
        return null;
    }
    
    public void addContato(String nome, Contato c){
        Pessoa p = buscarPessoa(nome);
        if (p!=null){
            p.addContato(c);
        }
    }
    
    public void exibirTodasPessoas(){
        for(int i=0; i<cont; i++){
            pessoas[i].exibir();
        }
    }
    
    public void exibirContatosPessoa(String nome){
        Pessoa p = buscarPessoa(nome);
        if (p!=null){
            p.exibir();
        }
    }
    
    public void exibirPessoaComEmail(){
        for(int i=0; i<cont; i++){
           if (pessoas[i].possuiEmail()){
               System.out.println(" - "+pessoas[i].getNome());
           }
        }
    }
    
    public void recuperarPessoaPorEmail(String email){
        for(int i=0; i<cont; i++){           
           if (pessoas[i].possuiEmail()){
               Contato vet[] = pessoas[i].getContatos("Email");
               for(int j=0; j<vet.length; j++){
                   Email e = (Email) vet[j];
                   if (e.getEmail().equals(email)){
                       System.out.println(" - "+pessoas[i].getNome());
                   }
               }
           }
        }
    }
    public void recuperarPessoaPorTelefone(String tel){
        for(int i=0; i<cont; i++){           
           if (pessoas[i].possuiTelefone()){
               Contato vet[] = pessoas[i].getContatos("Telefone");
               for(int j=0; j<vet.length; j++){
                  if (((Telefone)vet[j]).getTelefone().equals(tel)){
                      System.out.println(" - "+pessoas[i].getNome());
                  }
               }
           }
        }
    }
    
}

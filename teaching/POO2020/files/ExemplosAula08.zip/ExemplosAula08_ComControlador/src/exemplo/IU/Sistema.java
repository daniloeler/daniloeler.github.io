/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo.IU;

import exemplo.controlador.Controlador;
import exemplo.modelo.Conta;
import exemplo.modelo.ContaEspecial;
import java.util.Scanner;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Sistema {

    private int menu() {
        String menu = "MENU\n"
                + "1 – Cadastrar Nova Conta Simples\n"
                + "2 – Cadastrar Nova Conta Especial\n"
                + "3 – Saque\n"
                + "4 – Depósito\n"
                + "5 – Dados de uma conta específica\n"
                + "6 – Relatório Geral (todas as contas)\n"
                + "7 – Relatório de Contas Simples\n"
                + "8 – Relatório de Contas Especiais\n"
                + "9 – Sair\n";
        System.out.println(menu);
        Scanner sc = new Scanner(System.in);
        int op = Integer.parseInt(sc.nextLine());
        return op;
    }

    public void executar() {
        System.out.println("Exemplo com uso de controlador");
        int op;
        String numero;
        String titular;
        double saldo, limite, valor;
        Scanner sc = new Scanner(System.in);
        Controlador control = new Controlador();
        Conta c;
        do {
            op = menu();
            switch (op) {
                case 1://CADASTRO DE CONTA SIMPLES                    
                    System.out.println("Numero da Conta:");
                    numero = sc.nextLine();
                    System.out.println("Nome do Titular:");
                    titular = sc.nextLine();
                    System.out.println("Saldo: ");
                    saldo = Double.parseDouble(sc.nextLine());
                    control.addConta(numero, titular, saldo);
                    break;
                case 2://CADASTRO DE CONTA ESPECIAL
                    System.out.println("Numero da Conta:");
                    numero = sc.nextLine();
                    System.out.println("Nome do Titular:");
                    titular = sc.nextLine();
                    System.out.println("Saldo: ");
                    saldo = Double.parseDouble(sc.nextLine());
                    System.out.println("Limite: ");
                    limite = Double.parseDouble(sc.nextLine());
                    control.addContaEspecial(numero, titular, saldo, limite);
                    break;
                case 3://SAQUE                    
                    System.out.println("===SAQUE===");
                    System.out.print("Numero da Conta: ");
                    numero = sc.nextLine();
                    c = control.buscarConta(numero);
                    if (c != null) {
                        System.out.print("Valor do Saque: R$");
                        valor = Double.parseDouble(sc.nextLine());
                        control.sacar(numero, valor);
                    } else {
                        System.out.println("Conta não Encontrada");
                    }
                    break;
                case 4://DEPOSITO
                    System.out.println("===DEPÓSITO===");
                    System.out.println("Numero da Conta:");
                    numero = sc.nextLine();
                    c = control.buscarConta(numero);
                    if (c != null) {
                        System.out.print("Valor do Deposito: R$");
                        valor = Double.parseDouble(sc.nextLine());
                        control.depositar(numero, valor);
                    } else {
                        System.out.println("Conta não Encontrada");
                    }
                    break;
                case 5://DADOS DE UMA CONTA ESPECIFICA
                        System.out.println("Numero da Conta:");
                        numero = sc.nextLine();
                        c = control.buscarConta(numero);
                        if (c != null) {
                            c.depositar(50000);
                            c.exibir();
                        }

                    break;
                case 6://RELATORIO GERAL
                    System.out.println("Relatório Geral de Contas\n");
                    System.out.println(control.dadosTodasContas());
                    break;
                case 7://CONTAS SIMPLES
                    System.out.println("Relatório Geral de Contas Simples\n");
                    System.out.println(control.dadosTodasContasSimples());
                    break;
                case 8://CONTAS ESPECIAIS
                    System.out.println("Relatório Geral de Contas Especiais\n");
                    System.out.println(control.dadosTodasContasEspeciais());
                    break;
                case 9:
                    System.out.println("FIM");
                    break;
                default:
                    System.out.println("OPÇÃO INVÁLIDA");
                    break;
            }
        } while (op != 9);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class ContaEspecial extends Conta{
    private double limite;

    public ContaEspecial() {
        super();
        this.limite = 0;
        this.tipo="ContaEspecial";
    }

    public ContaEspecial(String numero, String titular, double saldo, double limite) {
        super(numero, titular, saldo);
        this.tipo="ContaEspecial";
        this.limite = limite;
    }

    public void depositar(double valor) {
        if (valor > 0) {
            saldo = saldo + valor;
        }
    }

    public void sacar(double valor) {
        if (saldo + limite - valor >= 0) {
            saldo = saldo - valor;
        }
    }

    public void exibir() {
        System.out.println("=============================");
        System.out.println("Número: " + numero);
        System.out.println("Titular: " + titular);
        System.out.println("Saldo R$ " + saldo);
        System.out.println("Limite R$ " + limite);
        System.out.println("=============================");
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo;

import java.util.Scanner;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Sistema {

    private Conta contas[];
    private int MAX = 100;
    private int cont;

    private int menu() {
        String menu = "MENU\n"
                + "1 – Cadastrar Nova Conta Simples\n"
                + "2 – Cadastrar Nova Conta Especial\n"
                + "3 – Saque\n"
                + "4 – Depósito\n"
                + "5 – Dados de uma conta específica\n"
                + "6 – Relatório Geral (todas as contas)\n"
                + "7 – Relatório de Contas Simples\n"
                + "8 – Relatório de Contas Especiais\n"
                + "9 – Sair\n";
        System.out.println(menu);
        Scanner sc = new Scanner(System.in);
        int op = Integer.parseInt(sc.nextLine());
        return op;
    }

    public Conta buscar(String num) {
        for (int i = 0; i < cont; i++) {
            if (contas[i].getNumero().equals(num)) {
                return contas[i];
            }
        }
        return null;
    }

    public Conta buscarTitular(String nome) {
        for (int i = 0; i < cont; i++) {
            if (contas[i].getTitular().equals(nome)) {
                return contas[i];
            }
        }
        return null;
    }

    public void executar() {
        System.out.println("Exemplo sem uso de controlador");
        int op;
        contas = new Conta[MAX];
        cont = 0;
        String numero;
        String titular;
        double saldo, limite, valor;
        Scanner sc = new Scanner(System.in);
        Conta c = null;
        do {
            op = menu();
            switch (op) {
                case 1://CADASTRO DE CONTA SIMPLES
                    if (cont < MAX) {
                        System.out.println("Numero da Conta:");
                        numero = sc.nextLine();
                        System.out.println("Nome do Titular:");
                        titular = sc.nextLine();
                        System.out.println("Saldo: ");
                        saldo = Double.parseDouble(sc.nextLine());
                        contas[cont] = new Conta(numero, titular, saldo);
                        cont++;
                    } else {
                        System.out.println("SEM ESPAÇO PARA CADASTRO");
                    }
                    break;
                case 2://CADASTRO DE CONTA ESPECIAL
                    if (cont < MAX) {
                        System.out.println("Numero da Conta:");
                        numero = sc.nextLine();
                        System.out.println("Nome do Titular:");
                        titular = sc.nextLine();
                        System.out.println("Saldo: ");
                        saldo = Double.parseDouble(sc.nextLine());
                        System.out.println("Limite: ");
                        limite = Double.parseDouble(sc.nextLine());
                        contas[cont] = new ContaEspecial(numero, titular, saldo, limite);
                        cont++;
                    } else {
                        System.out.println("SEM ESPAÇO PARA CADASTRO");
                    }
                    break;
                case 3://SAQUE
                    if (cont > 0) {
                        System.out.println("===SAQUE===");
                        System.out.print("Numero da Conta: ");
                        numero = sc.nextLine();
                        c = buscar(numero);
                        if (c != null) {
                            System.out.print("Valor do Saque: R$");
                            valor = Double.parseDouble(sc.nextLine());
                            c.sacar(valor);
                        } else {
                            System.out.println("Conta não Encontrada");
                        }
                    } else {
                        System.out.println("CONTAS NÃO CADASTRADAS");
                    }
                    break;
                case 4://DEPOSITO
                    if (cont > 0) {
                        System.out.println("===DEPÓSITO===");
                        System.out.println("Numero da Conta:");
                        numero = sc.nextLine();
                        c = buscar(numero);
                        if (c != null) {
                            System.out.print("Valor do Deposito: R$");
                            valor = Double.parseDouble(sc.nextLine());
                            c.depositar(valor);
                        } else {
                            System.out.println("Conta não Encontrada");
                        }
                    } else {
                        System.out.println("CONTAS NÃO CADASTRADAS");
                    }
                    break;
                case 5://DADOS DE UMA CONTA ESPECIFICA
                    if (cont > 0) {
                        System.out.println("Numero da Conta:");
                        numero = sc.nextLine();
                        c = buscar(numero);
                        if (c != null) {
                            c.exibir();
                        }
                    }
                    break;
                case 6://RELATORIO GERAL
                    if (cont > 0) {
                        for (int i = 0; i < cont; i++) {
                            contas[i].exibir();
                        }
                    } else {
                        System.out.println("CONTAS NÃO CADASTRADAS");
                    }
                    break;
                case 7://CONTAS SIMPLES
                    if (cont > 0) {
                        for (int i = 0; i < cont; i++) {
                            if (contas[i].getTipo().equals("Conta")) {
                                contas[i].exibir();
                            }
                        }
                    } else {
                        System.out.println("CONTAS NÃO CADASTRADAS");
                    }
                    break;
                case 8://CONTAS ESPECIAIS
                    if (cont > 0) {
                        for (int i = 0; i < cont; i++) {
                            if (contas[i].getTipo().equals("ContaEspecial")) {
                                contas[i].exibir();
                            }
                        }
                    } else {
                        System.out.println("CONTAS NÃO CADASTRADAS");
                    }
                    break;
                case 9:
                    System.out.println("FIM");
                    break;
                default:
                    System.out.println("OPÇÃO INVÁLIDA");
                    break;
            }
        } while (op != 9);
    }
}

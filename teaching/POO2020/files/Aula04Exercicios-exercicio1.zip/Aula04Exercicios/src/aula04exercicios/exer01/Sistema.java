/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04exercicios.exer01;

import java.util.Scanner;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Sistema {

    private int MAX = 100;
    private Aluno alunos[];
    private int cont;

    private int menu() {
        String menu = "MENU\n"
                + "1 – Cadastrar Aluno\n"
                + "2 – Listar Alunos (somente nome)\n"
                + "3 – Relatório Geral (exibe todas as informações)\n"
                + "4 – Informações de um Aluno\n"
                + "5 – IMC maior que um valor\n"
                + "9 – Sair\n";
        System.out.println(menu);
        System.out.print("Digite opção: ");
        Scanner sc = new Scanner(System.in);
        int op = Integer.parseInt(sc.nextLine());
        return op;
    }

    public Aluno buscar(String nome) {
        for (int i = 0; i < cont; i++) {
            if (alunos[i].getNome().equals(nome)) {
                return alunos[i];
            }
        }
        return null;
    }

    public void executar() {
        System.out.println("SISTEMA ACADEMIA");
        int op;
        alunos = new Aluno[MAX];
        cont = 0;
        String id;
        String nome;
        int idade;
        float peso;
        float altura;
        Scanner sc = new Scanner(System.in);

        do {
            op = menu();
            switch (op) {
                case 1:
                    if (cont < MAX) {
                        System.out.print("Identicador do aluno: ");
                        id = sc.nextLine();
                        System.out.print("Nome do aluno: ");
                        nome = sc.nextLine();
                        System.out.print("Idade do aluno: ");
                        idade = Integer.parseInt(sc.nextLine());
                        System.out.print("Peso do aluno: ");
                        peso = Float.parseFloat(sc.nextLine());
                        System.out.print("Altura do aluno: ");
                        altura = Float.parseFloat(sc.nextLine());

                        alunos[cont] = new Aluno(id, nome, idade, peso, altura);
                        cont++;
                    } else {
                        System.out.println("SEM ESPAÇO");
                    }

                    break;
                case 2:
                    if (cont > 0) {
                        System.out.println("\nALUNOS CADASTRADOS");
                        for (int i = 0; i < cont; i++) {
                            System.out.println(i + 1 + " - " + alunos[i].getNome());
                        }
                    } else {
                        System.out.println("NÃO TEM ALUNOS CADASTRADOS");
                    }
                    break;

                case 3:
                    if (cont > 0) {
                        for (int i = 0; i < cont; i++) {
                            alunos[i].exibir();
                        }
                    } else {
                        System.out.println("NÃO TEM ALUNOS CADASTRADOS");
                    }
                    break;

                case 4:
                    if (cont > 0) {
                        System.out.print("Nome do aluno: ");
                        nome = sc.nextLine();
                        Aluno a = buscar(nome);
                        if (a != null) {
                            a.exibir();
                        } else {
                            System.out.println("Aluno não cadastrado");
                        }

                    } else {
                        System.out.println("NÃO TEM ALUNOS CADASTRADOS");
                    }
                    break;
                case 5:
                    if (cont > 0) {
                        System.out.print("IMC parametro para busca: ");
                        float imc = Float.parseFloat(sc.nextLine());
                        for(int i=0; i<cont; i++){
                            if (alunos[i].IMC() >= imc){
                                System.out.println(" - "+alunos[i].getNome() +
                                        " -- IMC: "+alunos[i].IMC());
                            }
                        }
                    } else {
                        System.out.println("NÃO TEM ALUNOS CADASTRADOS");
                    }
                    break;
                default:
                    System.out.println("OPÇÃO INVÁLIDA");
                    break;
            }
        } while (op != 9);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula07;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Funcionario {
    private static int codAtual = 0;
    private int cod;
    private String nome;
    private int idade;
    private int qtdSalario;
    private final double SALARIO_BASE = 550.0;
    public static final String EMPRESA = "Superercados Associados";

    public Funcionario(String nome, int idade, int qtdSalario) {
        this.cod = codAtual;
        this.codAtual++;
        this.nome = nome;
        this.idade = idade;
        this.qtdSalario = qtdSalario;
    }
    
    public void exibir(){
        System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
        System.out.println("Código: "+cod);
        System.out.println("Nome: "+nome);
        System.out.println("Idade: "+idade);
        System.out.println("Salario: R$"+SALARIO_BASE*qtdSalario);
        System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");        
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
    
}

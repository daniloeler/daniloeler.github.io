/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula07;

import javax.swing.JOptionPane;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class ExemplosAula07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /////Exemplo Math
        System.out.println("PI: "+Math.PI);
        System.out.println("Raiz: "+Math.sqrt(900));
        System.out.println("Menor: "+Math.min(50, 40));
        //Math m = new Math();
        
        /////Exemplo JOptionPane
        
        JOptionPane.showMessageDialog(null, "Produto Cadastrado com Sucesso");
        String nome = JOptionPane.showInputDialog("Digite Nome do Funcionario");
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite Idade do Funcionario"));
        JOptionPane.showMessageDialog(null, "Nome: "+nome+"\nIdade: "+idade);
        
        /////Exemplo Util
        int vetor[] = {1,2,30,4,5,6};
        
        System.out.println("Media: "+Util.media(vetor));
        System.out.println("Maior: "+Util.maior(vetor));
        
//        /////Exemplo Funcionario
        Funcionario f1 = new Funcionario("F1", 22,1);
        Funcionario f2 = new Funcionario("F2", 33,2);
        Funcionario f3 = new Funcionario("F2", 44,3);
        System.out.println("Funcionarios da Empresa: "+Funcionario.EMPRESA);
        f1.exibir();
        f2.exibir();
        f3.exibir();
    }
    
}

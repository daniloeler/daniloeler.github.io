/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula07;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Util {
    public static float media(int vet[]){
        float soma = 0;
        for(int i=0; i<vet.length; i++){
            soma = soma + vet[i];
        }
        return soma/vet.length;
    }
    
    public static int maior(int vet[]){
        int maior = vet[0];
        for(int i=0;i<vet.length;i++){
            if (vet[i]>maior){
                maior = vet[i];
            }
        }
        
        return maior;
    }
}

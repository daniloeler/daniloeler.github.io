/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

import java.awt.BorderLayout;
import java.util.Scanner;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class SistemaProdutos {
    private Produto produtos[];
    private int MAX = 1000;
    private int cont;

    private int menu() {
        String menu = "MENU\n"
                + "1 – Cadastrar Produto Estadual\n"
                + "2 – Cadastrar Produto Nacional\n"
                + "3 – Cadastrar Produto Importado\n"
                + "4 – Exibir Produtos Estaduais\n"
                + "5 – Exibir Produtos Nacionais\n"
                + "6 – Exibir Produtos Importados\n"
                + "7 – Exibir Todos Produtos\n"
                + "9 – SAIR";
        System.out.println(menu);
        int op;
        Scanner sc = new Scanner(System.in);
        System.out.print("Digite Opção Desejada: ");
        op = Integer.parseInt(sc.nextLine()); 
        return op;
    }

    public void executar() {
        int op = 0;
        cont = 0;
        produtos = new Produto[MAX];
        String desc;
        double valor, taxa=5, imposto=10, taxaImportacao=5;
        Scanner sc = new Scanner(System.in);
        do{
            op = menu();
           switch(op){
               case 1:
                   if (cont < MAX){
                       System.out.print("Descrição do Produto: ");
                       desc = sc.nextLine();
                       System.out.print("Valor do Produto: R$ ");
                       valor = Double.parseDouble(sc.nextLine());
                       produtos[cont] = new Estadual(desc, valor, imposto);
                       cont++;
                   }else{
                       System.out.println("SEM ESPAÇO PARA UM NOVO CADASTRO");                              
                   }
                   break;
               case 2:
                   if (cont < MAX){
                       System.out.print("Descrição do Produto: ");
                       desc = sc.nextLine();
                       System.out.print("Valor do Produto: R$ ");
                       valor = Double.parseDouble(sc.nextLine());
                       produtos[cont] = new Nacional(desc, valor, imposto, taxa);
                       cont++;
                   }else{
                       System.out.println("SEM ESPAÇO PARA UM NOVO CADASTRO");                              
                   }
                   break;                   
               case 3:
                   if (cont < MAX){
                       System.out.print("Descrição do Produto: ");
                       desc = sc.nextLine();
                       System.out.print("Valor do Produto: R$ ");
                       valor = Double.parseDouble(sc.nextLine());
                       produtos[cont] = new Importado(desc, valor, imposto, taxa, taxaImportacao);
                       cont++;
                   }else{
                       System.out.println("SEM ESPAÇO PARA UM NOVO CADASTRO");                              
                   }
                   break;    
               case 4:
                   if (cont > 0){
                       for (int i = 0; i < cont; i++) {
                           if (produtos[i] instanceof Estadual){
                                produtos[i].exibir();
                           }
                       }
                   }else{
                       System.out.println("NENHUM PRODUTO CADASTRADO");                   
                   }
                   break;    
               case 5:
                   if (cont > 0){
                       for (int i = 0; i < cont; i++) {
                           if (produtos[i] instanceof Nacional){
                                produtos[i].exibir();
                           }
                       }
                   }else{
                       System.out.println("NENHUM PRODUTO CADASTRADO");                   
                   }
                   break;                   
               case 6:
                   if (cont > 0){
                       for (int i = 0; i < cont; i++) {
                           if (produtos[i] instanceof Importado){
                                produtos[i].exibir();
                           }
                       }
                   }else{
                       System.out.println("NENHUM PRODUTO CADASTRADO");                   
                   }
                   break;    
               case 7:
                   if (cont > 0){
                       for (int i = 0; i < cont; i++) {
                           produtos[i].exibir();
                       }
                   }else{
                       System.out.println("NENHUM PRODUTO CADASTRADO");                   
                   }
                   break;        
           }
        }while (op != 9);
    }
}

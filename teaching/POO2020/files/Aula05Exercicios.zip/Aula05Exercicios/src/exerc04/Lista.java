/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc04;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Lista {
    protected int vetor[];
    protected int MAX;
    protected int cont;
    public Lista() {
        MAX = 100;
        cont = 0;
        vetor = new int[MAX];
    }

    public Lista(int MAX) {
        this.MAX = MAX;
        cont = 0;
        vetor = new int[MAX];
    }

    public void add(int elem) {
        if (cont < MAX) {
            vetor[cont] = elem;
            cont++;
        }
    }

    public int posElemento(int elem) {
        for (int i = 0; i < cont; i++) {
            if (vetor[i] == elem) {
                return i;
            }
        }
        return -1;
    }

    public void remover(int elem) {
        int pos = posElemento(elem);
        if (pos != -1){
            vetor[pos] = vetor[cont-1];
            cont--;
        }
    }

    public int qtdElementos() {
        return cont;
    }

    public void exibir() {
        for (int i = 0; i < cont; i++) {
            System.out.println(vetor[i]);
        }
    }
}

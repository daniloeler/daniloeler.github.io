/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc04;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class ListaOrdenada extends Lista {

    public ListaOrdenada() {
        super();
    }

    public ListaOrdenada(int MAX) {
        super(MAX);
    }

    public void add(int elem) {
        if (cont < MAX) {
            int i = cont;
            while (i > 0 && vetor[i - 1] > elem) {
                vetor[i] = vetor[i - 1];
                i--;
            }
            vetor[i] = elem;
            cont++;
        }
    }

    public void remover(int elem) {
        int pos = posElemento(elem);
        if (pos != -1) {
            for (int i = pos; i < cont-1; i++) {
                vetor[i] = vetor[i + 1];
            }
            cont--;
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc04;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class PrincipalExer4 {
    public static void main(String[] args) {
        Lista l = new Lista(20);
        l.add(4);
        l.add(3);
        l.add(5);
        l.add(33);
        l.add(15);
        l.exibir();
        System.out.println("Quantidade de Elementos: "+l.qtdElementos());
        System.out.println("Pos Elemento 33: "+l.posElemento(15));
        l.remover(3);
        l.exibir();
        System.out.println("Quantidade de Elementos: "+l.qtdElementos());
        
        System.out.println("\nLISTA ORDENADA\n");
        l = new ListaOrdenada(20);
        l.add(1);
        l.add(4);
        l.add(3);
        l.add(5);
        l.add(33);
        l.add(15);
        l.exibir();
        System.out.println("Quantidade de Elementos: "+l.qtdElementos());
        System.out.println("Pos Elemento 33: "+l.posElemento(15));
        l.remover(3);
        l.exibir();
        System.out.println("Quantidade de Elementos: "+l.qtdElementos());
    }
}

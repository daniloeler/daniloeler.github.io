/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc03;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class PrincipalExer03 {
    public static void main(String[] args) {
        SistemaUniversidade sis = new SistemaUniversidade();
        sis.executar();
    }
}

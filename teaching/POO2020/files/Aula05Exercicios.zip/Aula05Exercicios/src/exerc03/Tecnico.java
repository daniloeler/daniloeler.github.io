/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc03;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Tecnico extends Funcionario{
    protected String nivel;
    public Tecnico(){
        super();
    }

    public Tecnico(String codigo, String nome, double salario, String nivel) {
        super(codigo, nome, salario);
        this.nivel = nivel;
    }
    
    public void exibir(){
        super.exibir();
        System.out.println("Nível: "+nivel);
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc03;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Departamento {

    private String codigo;
    private String nome;
    private Funcionario funcionarios[];
    private int cont;
    private int MAX;

    public Departamento() {
        MAX = 1000;
        cont = 0;
        funcionarios = new Funcionario[MAX];
    }

    public Departamento(String codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
        MAX = 1000;
        cont = 0;
        funcionarios = new Funcionario[MAX];
    }

    public void addFuncionario(Funcionario f) {
        if (cont < MAX) {
            funcionarios[cont] = f;
            cont++;
        }
    }

    public void exibir() {
        System.out.println("Código: " + codigo + " Nome: " + nome);
        for (int i = 0; i < cont; i++) {
            funcionarios[i].exibir();
        }
    }

    public void exibirFuncionarios() {
        for (int i = 0; i < cont; i++) {
            funcionarios[i].exibir();
        }
    }

    public void exibirTecnicos() {
        for (int i = 0; i < cont; i++) {
            if (funcionarios[i] instanceof Tecnico) {
                funcionarios[i].exibir();
            }
        }
    }
    
     public void exibirDocentes() {
        for (int i = 0; i < cont; i++) {
            if (funcionarios[i] instanceof Docente) {
                funcionarios[i].exibir();
            }
        }
    }

    public double gastoTotal() {
        double soma = 0;
        for (int i = 0; i < cont; i++) {
            soma = soma + funcionarios[i].calcularSalario();
        }
        return soma;
    }

    public void funcFaixaSalario(double ini, double fin) {
        for (int i = 0; i < cont; i++) {
            double salario = funcionarios[i].calcularSalario();
            if (ini <= salario && salario <= fin) {
                System.out.println("  -- " + funcionarios[i].getNome());
            }
        }
    }

    public boolean deptoFuncFaixaSalario(double ini, double fin) {
        for (int i = 0; i < cont; i++) {
            double salario = funcionarios[i].calcularSalario();
            if (ini <= salario && salario <= fin) {
                return true;
            }
        }
        return false;
    }

    public Funcionario buscarFuncNome(String nome) {
        for (int i = 0; i < cont; i++) {
            if (funcionarios[i].getNome().equals(nome)) {
                return funcionarios[i];
            }
        }
        return null;
    }

    public int getQtdFuncionarios() {
        return cont;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}

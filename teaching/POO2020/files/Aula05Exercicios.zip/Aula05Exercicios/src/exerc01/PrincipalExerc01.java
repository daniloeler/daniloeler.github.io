/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc01;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class PrincipalExerc01 {
    public static void main(String[] args) {
        Peca p1 = new Peca("Mouse", 20, 10);
        p1.exibir();
        System.out.println("*****");
        PecaImportada p2 = new PecaImportada("Memoria", 100, 10, 10, 10);
        p2.exibir();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula02.exerc3_4;

/**
 *
 * @author danil
 */
public class Lista {

    private int vetor[];
    private int cont;
    private int max;

    public void inicializar(int max) {
        this.max = max;
        vetor = new int[max];
        cont = 0;
    }

    public boolean listaVazia() {
        if (cont == 0) {
            return true;
        }
        return false;
    }

    public boolean listaCheia() {
        if (cont == max) {
            return true;
        }
        return false;
    }

    public void add(int elem) {
        if (!listaCheia()) {
            vetor[cont] = elem;
            cont++;
        }
    }

    public int buscarElem(int elem) {
        if (!listaVazia()) {
            for (int i = 0; i < cont; i++) {
                if (vetor[i] == elem) {
                    return i;
                }
            }
        }
        return -1;
    }

    public void remover(int elem) {
        int pos = buscarElem(elem);
        if (pos != -1) {
            vetor[pos] = vetor[cont - 1];
            cont--;
        }
    }

    public void imprimirLista() {
        if (!listaVazia()) {
            System.out.print("\n| ");
            for (int i = 0; i < cont - 1; i++) {
                System.out.print(vetor[i] + ", ");
            }
            System.out.print(vetor[cont-1] + " |\n");
        } else {
            System.out.println("\n|  |\n");
        }
    }
}

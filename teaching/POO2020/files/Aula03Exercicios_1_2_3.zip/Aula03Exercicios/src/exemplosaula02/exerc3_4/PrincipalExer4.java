/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula02.exerc3_4;

/**
 *
 * @author danil
 */
public class PrincipalExer4 {
    public static void main(String[] args) {
        Lista l = new Lista();
        l.inicializar(10);
        l.imprimirLista();
        l.add(5);
        l.imprimirLista();
        l.add(1);
        l.add(2);
        l.add(3);
        l.imprimirLista();
        l.remover(1);
        l.imprimirLista();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula02.exerc3_4;

/**
 *
 * @author danil
 */
public class Departamento {
    private String cod;
    private String nome;
    private String telefone;
    private Funcionario funcionarios[];
    private int cont;
    private int max;
    
     public void inicializar(int max) {
        this.max = max;
        funcionarios = new Funcionario[max];
        cont = 0;
    }
     
     public void add(Funcionario f){
         if (cont < max){
             funcionarios[cont] = f;
             cont++;
         }
     }
     
     public Funcionario buscarFuncionar(String nome){
         for(int i=0;i < cont; i++){
             if (funcionarios[i].getNome().equals(nome))
                 return funcionarios[i];
         }
         return null;
     }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
     
}

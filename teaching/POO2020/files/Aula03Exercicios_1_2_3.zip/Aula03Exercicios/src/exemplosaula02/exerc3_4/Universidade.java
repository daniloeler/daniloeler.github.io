/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosaula02.exerc3_4;

/**
 *
 * @author danil
 */
public class Universidade {

    private String nome;
    private Departamento departamentos[];
    private int cont;
    private int max;

    public void inicializar(int max) {
        this.max = max;
        departamentos = new Departamento[max];
        cont = 0;
    }

    public void add(Departamento d) {
        if (cont < max) {
            departamentos[cont] = d;
            cont++;
        }
    }
    
     public Departamento buscarDepartamento(String nome){
         for(int i=0;i < cont; i++){
             if (departamentos[i].getNome().equals(nome))
                 return departamentos[i];
         }
         return null;
     }
     
     public Funcionario buscarFuncionario(String nome){
         for (int i=0; i<cont; i++){
             Funcionario f = departamentos[i].buscarFuncionar(nome);
             if (f!=null)
                 return f;
         }
         return null;
     }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.modelo;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Item {
    private int num;
    private String codProduto; //codigo do codProduto
    private float valor; //valor do codProduto
    private float quant; //quantidade comprada

    public Item(int num, String codProduto, float valor, float quant) {
        this.num = num;
        this.codProduto = codProduto;
        this.valor = valor;
        this.quant = quant;
    }

    @Override
    public String toString() {
        return "num=" + num + ", codProduto=" + codProduto + ", valor=" + valor + ", quant=" + quant + ", subtotal "+quant*valor;
    }
    
    

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getProduto() {
        return codProduto;
    }

    public void setProduto(String codProduto) {
        this.codProduto = codProduto;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public float getQuant() {
        return quant;
    }

    public void setQuant(float quant) {
        this.quant = quant;
    }    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04exercicios.exer03;

import java.util.Scanner;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class SistemaProdutos {

    private ProdutoEstadual vecPE[];
    private ProdutoNacional vecPN[];
    private ProdutoImportado vecPI[];
    private int contPE;
    private int contPN;
    private int contPI;
    private int MAX = 1000;

    private int menu() {
        String menu = "MENU\n"
                + "1 – Cadastrar Produto Estadual\n"
                + "2 – Cadastrar Produto Nacional\n"
                + "3 – Cadastrar Produto Importado\n"
                + "4 – Exibir Produtos Estaduais\n"
                + "5 – Exibir Produtos Nacionais\n"
                + "6 – Exibir Produtos Importados\n"
                + "7 – Exibir Todos Produtos\n"
                + "9 – SAIR\n";
        System.out.println(menu);
        System.out.print("Digite Opção: ");
        Scanner sc = new Scanner(System.in);
        int op = Integer.parseInt(sc.nextLine());
        return op;
    }

    public void executar() {
        System.out.println("SISTEMA DE PRODUTOS");
        vecPE = new ProdutoEstadual[MAX];
        vecPN = new ProdutoNacional[MAX];
        vecPI = new ProdutoImportado[MAX];
        String descricao;
        double valor, imposto, taxa, taxaImport;
        int op;
        Scanner sc = new Scanner(System.in);
                
        do {
            op = menu();
            switch (op) {
                case 1://cad produto estadual
                    System.out.print("Nome do Produto Estadual: ");
                    descricao = sc.nextLine();
                    System.out.print("Valor do Produto:");
                    valor = Double.parseDouble(sc.nextLine());
                    System.out.print("Valor do Imposto: ");
                    imposto = Double.parseDouble(sc.nextLine());
                    if (contPE < MAX) {
                        vecPE[contPE] = new ProdutoEstadual(descricao, valor, imposto);
                        contPE++;
                    }
                    break;
                case 2:
                    System.out.print("Nome do Produto Nacional: ");
                    descricao = sc.nextLine();
                    System.out.print("Valor do Produto:");
                    valor = Double.parseDouble(sc.nextLine());
                    System.out.print("Valor do Imposto: ");
                    imposto = Double.parseDouble(sc.nextLine());
                    System.out.print("Valor da Taxa: ");
                    taxa = Double.parseDouble(sc.nextLine());
                    if (contPN < MAX) {
                        vecPN[contPN] = new ProdutoNacional(descricao, valor, imposto, taxa);
                        contPN++;
                    }
                    break;
                case 3:
                    System.out.print("Nome do Produto Nacional: ");
                    descricao = sc.nextLine();
                    System.out.print("Valor do Produto:");
                    valor = Double.parseDouble(sc.nextLine());
                    System.out.print("Valor do Imposto: ");
                    imposto = Double.parseDouble(sc.nextLine());
                    System.out.print("Valor da Taxa: ");
                    taxa = Double.parseDouble(sc.nextLine());
                    System.out.print("Valor da Taxa de Importacao: ");
                    taxaImport = Double.parseDouble(sc.nextLine());
                    if (contPI < MAX) {
                        vecPI[contPI] = new ProdutoImportado(descricao, valor, imposto, taxa, taxaImport);
                        contPI++;
                    }
                    break;
                case 4://exibir prod estadual
                    if (contPE > 0) {
                        for (int i = 0; i < contPE; i++) {
                            vecPE[i].exibir();
                        }
                    }else{
                        System.out.println("Nenhum produto estadual cadastrado");
                    }
                    break;
                case 5://exibir prod nacional
                    if (contPN > 0) {
                        for (int i = 0; i < contPN; i++) {
                            vecPN[i].exibir();
                        }
                    }else{
                        System.out.println("Nenhum produto nacional cadastrado");
                    }
                    break;
                case 6:
                    if (contPI > 0) {
                        for (int i = 0; i < contPI; i++) {
                            vecPI[i].exibir();
                        }
                    }else{
                        System.out.println("Nenhum produto importado cadastrado");
                    }
                    break;
                case 7:
                    if (contPE > 0) {
                        for (int i = 0; i < contPE; i++) {
                            vecPE[i].exibir();
                        }
                    }else{
                        System.out.println("Nenhum produto estadual cadastrado");
                    }
                    if (contPN > 0) {
                        for (int i = 0; i < contPN; i++) {
                            vecPN[i].exibir();
                        }
                    }else{
                        System.out.println("Nenhum produto nacional cadastrado");
                    }
                    if (contPI > 0) {
                        for (int i = 0; i < contPI; i++) {
                            vecPI[i].exibir();
                        }
                    }else{
                        System.out.println("Nenhum produto importado cadastrado");
                    }
                    break;
                default:
                    System.out.println("OPÇÃO INVÁLIDA");
            }
        } while (op != 9);
    }
}

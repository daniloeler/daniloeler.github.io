/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04exercicios.exer03;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class ProdutoEstadual {
     private String descricao;
     private double valor;
     private double imposto;
     
     public ProdutoEstadual(){
         imposto = 10;
     }
     
     public ProdutoEstadual(String descricao, double valor, double imposto){
         this.descricao = descricao;
         this.valor = valor;
         this.imposto = imposto;
     }
     
    public double calcularValor(){
        return valor + valor * imposto / 100;
    } 
     
    public void exibir(){
        System.out.println("Descrição: "+descricao);
        System.out.println("Valor: R$ "+valor);
        System.out.println("Imposto: R$ "+imposto);
        System.out.println("Valor Final: R$ "+calcularValor());
    } 

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getImposto() {
        return imposto;
    }

    public void setImposto(double imposto) {
        this.imposto = imposto;
    }
}

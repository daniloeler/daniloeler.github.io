/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04exercicios.exer02;

import java.util.Scanner;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Sistema {

    private Conta contas[];
    private int MAX = 100;
    private int cont;

    private int menu() {
        String menu = "MENU\n"
                + "1 – Cadastrar Nova Conta\n"
                + "2 – Saque\n"
                + "3 – Depósito\n"
                + "4 – Listar Contas (posição do vetor e nome dos clientes)\n"
                + "5 – Relatório Geral (todas as contas)\n"
                + "6 – Relatório de Contas cujo saldo está abaixo de zero\n"
                + "7 – Relatório da Conta de um determinado cliente\n"
                + "9 – Sair\n";
        System.out.println(menu);
        Scanner sc = new Scanner(System.in);
        int op = Integer.parseInt(sc.nextLine());
        return op;
    }

    public Conta buscar(String num) {
        for (int i = 0; i < cont; i++) {
            if (contas[i].getNumero().equals(num)) {
                return contas[i];
            }
        }
        return null;
    }
    
    public Conta buscarTitular(String nome){
        for(int i=0; i<cont;i++){
            if (contas[i].getTitular().equals(nome)){
                return contas[i];
            }
        }
        return null;
    }

    public void executar() {
        System.out.println("EXERCÍCIO 02");
        int op;
        contas = new Conta[MAX];
        cont = 0;
        String numero;
        String titular;
        double saldo, limite, valor;
        Scanner sc = new Scanner(System.in);
        Conta c = null;
        do {
            op = menu();
            switch (op) {
                case 1://CADASTRO DE CONTA
                    if (cont < MAX) {
                        System.out.println("Numero da Conta:");
                        numero = sc.nextLine();
                        System.out.println("Nome do Titular:");
                        titular = sc.nextLine();
                        System.out.println("Saldo: ");
                        saldo = Double.parseDouble(sc.nextLine());
                        System.out.println("Limite: ");
                        limite = Double.parseDouble(sc.nextLine());
                        contas[cont] = new Conta(numero, titular, saldo, limite);
                        cont++;
                    } else {
                        System.out.println("SEM ESPAÇO PARA CADASTRO");
                    }
                    break;
                case 2://SAQUE
                    if (cont > 0) {
                        System.out.println("===SAQUE===");
                        System.out.print("Numero da Conta: ");
                        numero = sc.nextLine();
                        c = buscar(numero);
                        if (c != null) {
                            System.out.print("Valor do Saque: R$");
                            valor = Double.parseDouble(sc.nextLine());
                            c.sacar(valor);
                        } else {
                            System.out.println("Conta não Encontrada");
                        }
                    } else {
                        System.out.println("CLIENTES NÃO CADASTRADOS");
                    }
                    break;
                case 3://DEPOSITO
                    if (cont > 0) {
                        System.out.println("===DEPÓSITO===");
                        System.out.println("Numero da Conta:");
                        numero = sc.nextLine();
                        c = buscar(numero);
                        if (c != null) {
                            System.out.print("Valor do Deposito: R$");
                            valor = Double.parseDouble(sc.nextLine());
                            c.depositar(valor);
                        } else {
                            System.out.println("Conta não Encontrada");
                        }
                    } else {
                        System.out.println("CLIENTES NÃO CADASTRADOS");
                    }
                    break;
                case 4://NOME DOS CLIENTES E POSICAO DO VETOR
                    if (cont > 0) {
                        for (int i = 0; i < cont; i++) {
                            System.out.println(i + " - " + contas[i].getTitular());
                        }
                    } else {
                        System.out.println("CLIENTES NÃO CADASTRADOS");
                    }
                    break;
                case 5://RELATORIO GERAL
                    if (cont > 0) {
                        for (int i = 0; i < cont; i++) {
                            contas[i].exibir();
                        }
                    } else {
                        System.out.println("CLIENTES NÃO CADASTRADOS");
                    }
                    break;
                case 6://CONTAS COM SALDO NEGATIVO
                    if (cont > 0) {
                        System.out.println("====CLIENTES COM SALDO NEGATIVO====");
                        for (int i = 0; i < cont; i++) {
                            if (contas[i].getSaldo()<0){
                                System.out.println(" - "+contas[i].getTitular());
                            }
                        }
                    } else {
                        System.out.println("CLIENTES NÃO CADASTRADOS");
                    }
                    break;
                case 7://CONTA DE UM CLIENTE
                    if (cont > 0) {
                        System.out.println("Nome do Titular:");
                        titular = sc.nextLine();
                        c = buscarTitular(titular);
                        if (c!=null){
                            c.exibir();
                        }else{
                            System.out.println("CLIENTE NÃO ENCONTRADO");
                        }
                    } else {
                        System.out.println("CLIENTES NÃO CADASTRADOS");
                    }
                    break;
                default:
                    System.out.println("OPÇÃO INVÁLIDA");
                    break;
            }
        } while (op != 9);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parte3.controlador;

import parte3.modelo.Cliente;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Controlador {
    //O foco é a interface gráfica, por isso, essa classe que simula um controlador
    //Não foram implementados os modelos e a classe de armazenamento de dados.
    
    
    //metodo que simula o retorno de clientes
    public Cliente[] getClientes(){
        Cliente vetor[] = new Cliente[5];
        vetor[0] = new Cliente("Cliente 1","1111111-11",18);
        vetor[1] = new Cliente("Cliente 2","2222222-22",22);
        vetor[2] = new Cliente("Cliente 3","3333333-33",38);
        vetor[3] = new Cliente("Cliente 4","4444444-44",24);
        vetor[4] = new Cliente("Cliente 5","5555555-55",55);
        return vetor;
    }
}

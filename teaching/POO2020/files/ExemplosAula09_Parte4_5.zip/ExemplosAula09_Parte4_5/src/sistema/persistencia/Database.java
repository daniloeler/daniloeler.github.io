/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.persistencia;

import sistema.modelo.Cliente;
import sistema.modelo.Produto;
import sistema.modelo.Venda;


/**
 *
 * @author Danilo
 */
public final class Database {    
    private static final int MAX = 10000;
    private Produto[] vetProdutos;
    private int contProdutos;
    private Cliente[] vetClientes;
    private int contClientes;
    private Venda[] vetVendas;
    private int contVendas;
    private static Database instance;
    
    private Database(){
        this.vetProdutos = new Produto[MAX];
        this.vetClientes = new Cliente[MAX];
        this.vetVendas = new Venda[MAX];
        this.contProdutos = 0;
        this.contVendas = 0;
        this.instance = null;
    }
    
    public static Database getInstance(){
        if (instance == null){
            instance = new Database();
        }
        return instance;
    }
    
    public void addProduto(Produto p){
        if (contProdutos < MAX){
            vetProdutos[contProdutos] = p;
            contProdutos++;
        }
    }
    
    public void addCliente(Cliente c){
        if (contClientes < MAX){
            vetClientes[contClientes] = c;
            contClientes++;
        }
    }
    
    public void addVenda(Venda v){
        if (contVendas < MAX){
            vetVendas[contVendas] = v;
            contVendas++;
        }
    }
    
    public Cliente buscarClientePorCPF(String CPF){
        for(int i=0; i<contClientes; i++){
            if (vetClientes[i].getCPF().equals(CPF)){
                return vetClientes[i];
            }
        }
        return null;
    }
    
    public Venda buscarVendaPorNum(int num){
         for(int i=0; i<contVendas; i++){
             if (vetVendas[i].getNum() == num){
                 return vetVendas[i];
             }
         }
         return null;
    }
    
    public Cliente[] getClientes(){
        Cliente clientes[] = new Cliente[contClientes];
         for(int i=0; i<contProdutos;i++){
             clientes[i] = vetClientes[i].clone();
         }
        return clientes;
    }
    
    public Produto[] produtos(){
        Produto produtos[] = new Produto[contProdutos];
        for(int i=0; i<contProdutos;i++){
            produtos[i] = vetProdutos[i].clone();
        }
        return produtos;
    }
}

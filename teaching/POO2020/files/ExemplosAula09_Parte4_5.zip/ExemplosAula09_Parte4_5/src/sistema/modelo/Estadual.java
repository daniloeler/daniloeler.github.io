/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.modelo;

/**
 *
 * @author danilo
 */
public class Estadual extends Produto{
    public Estadual() {
        this.tipo = "Estadual";
    }

    public Estadual(String codigo, String descricao, float valor, float imposto) {
        super(codigo, descricao, valor, imposto);
        this.tipo = "Estadual";
    }
    
    public float calcularPrecoFinal(){
        return valor + valor*imposto/100;
    }
    
    @Override
    public String toString() {
        return "Estadual{"  + "codigo=" + codigo + ",descricao=" + descricao + ", valor=" + valor + ", imposto=" + imposto + ", tipo=" + tipo + '}';
    }
}

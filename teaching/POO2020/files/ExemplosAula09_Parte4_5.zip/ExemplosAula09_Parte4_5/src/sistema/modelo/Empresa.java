/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.modelo;

import java.util.logging.Level;
import java.util.logging.Logger;
import sistema.persistencia.Database;

/**
 *
 * @author Danilo
 */
public class Empresa {

    private static Database database;
    private Venda vendaAtual;

    public Empresa() {
        this.database = Database.getInstance();
        this.vendaAtual = null;
    }

    public void addProdutoEstadual(String codigo, String nome, float valor, float imposto) {
        Estadual e = new Estadual(codigo, nome, valor, imposto);
        database.addProduto(e);
    }

    public void addProdutoNacional(String codigo, String nome, float valor, float imposto, float taxa) {
        Nacional n = new Nacional(codigo, nome, valor, imposto, taxa);
        database.addProduto(n);
    }

    public void addProdutoImportado(String codigo, String nome, float valor, float imposto, float taxa, float taxaImp) {
        Importado i = new Importado(codigo, nome, valor, imposto, taxa, taxaImp);
        database.addProduto(i);
    }
    
    public void addCliente(String nome, String CPF, int idade){
        Cliente c = new Cliente(nome, CPF, idade);
        database.addCliente(c);
    }

    public String dadosProdutosEstaduais() {
        Produto vetor[] = database.produtos();
        String dados = "";
        for (int i = 0; i<vetor.length; i++) {
            if (vetor[i] instanceof Estadual) {
                dados = dados
                        + "Nome: " + vetor[i].getDescricao() + "\n"
                        + "valor: " + vetor[i].getValor() + "\n";
            }
        }
        return dados;
    }

    public String dadosProdutosNacionais() {
        Produto vetor[] = database.produtos();
        String dados = "";
        for (int i = 0; i<vetor.length; i++) {
            if (vetor[i] instanceof Nacional) {
                dados = dados
                        + "Nome: " + vetor[i].getDescricao() + "\n"
                        + "valor: " + vetor[i].getValor() + "\n";
            }
        }
        return dados;
    }

    public String dadosProdutosImportados() {
        Produto vetor[] = database.produtos();
        String dados = "";
        for (int i = 0; i<vetor.length; i++) {
            if (vetor[i] instanceof Importado) {
                dados = dados
                        + "Nome: " + vetor[i].getDescricao() + "\n"
                        + "valor: " + vetor[i].getValor() + "\n";
            }
        }
        return dados;
    }

    public Produto buscarProdutoPorCodigo(String codigo) {
        Produto vetor[] = database.produtos();
        for (int i = 0; i<vetor.length; i++) {
            if (vetor[i].getCodigo().equals(codigo)) {
                return vetor[i].clone();
            }
        }
        return null;
    }

    public Produto buscarProdutoPorNome(String descricao) {
        Produto vetor[] = database.produtos();

        for (int i = 0; vetor[i] != null; i++) {
            if (vetor[i].getDescricao().equals(descricao)) {
                return vetor[i].clone();
            }
        }
        return null;
    }
    
    public Cliente buscarClientePorCPF(String CPF){
        return database.buscarClientePorCPF(CPF);
    }
    
    public Venda buscarVendaPorNum(int num){
        return database.buscarVendaPorNum(num);
    }
    
    public Cliente[] getClientes(){
        return database.getClientes();
    }

    public Produto[] getProdutos() {
        return database.produtos();
    }
    
    public void novaVenda(int num, String CPF, int qtdItens){
        this.vendaAtual = new Venda(num, CPF, qtdItens);
    }
    
    public void addItem(int numero, String codProduto, float valor, float quant) {
        this.vendaAtual.addItem(numero, codProduto, valor, quant);
    }
    
    public void gravarVenda(){
        database.addVenda(vendaAtual);
        this.vendaAtual = null;
    }

}

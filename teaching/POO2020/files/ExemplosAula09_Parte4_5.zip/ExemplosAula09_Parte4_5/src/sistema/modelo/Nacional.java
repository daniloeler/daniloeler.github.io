/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.modelo;

/**
 *
 * @author danilo
 */
public class Nacional extends Produto{
    private float taxa;

    public Nacional() {
        this.tipo = "Nacional";
    }

    public Nacional(String codigo, String descricao, float valor, float imposto, float taxa) {
        super(codigo, descricao, valor, imposto);
        this.taxa = taxa;
        this.tipo = "Nacional";
    }
    
    public float calcularPrecoFinal(){
        return valor + valor*imposto/100 + valor*taxa/100;
    }

    public float getTaxa() {
        return taxa;
    }

    public void setTaxa(float taxa) {
        this.taxa = taxa;
    }

    @Override
    public String toString() {
        return "Nacional{" + "codigo=" + codigo + ",descricao=" + descricao + ", valor=" + valor + ", imposto=" + imposto + ", tipo=" + tipo + ", taxa=" + taxa + '}';
    }
    
    
}

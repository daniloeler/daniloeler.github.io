/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.modelo;

/**
 *
 * @author danilo
 */
public class Importado extends Produto {

    private float taxa;
    private float taxaImportacao;

    public Importado() {
        this.tipo = "Importado";
    }

    public Importado(String codigo, String descricao, float valor, float imposto, float taxa, float taxaImportacao) {
        super(codigo, descricao, valor, imposto);
        this.taxa = taxa;
        this.taxaImportacao = taxaImportacao;
        this.tipo = "Importado";
    }

    public float calcularPrecoFinal() {
        return valor + valor * imposto / 100 + valor * taxa / 100 + valor * taxaImportacao / 100;
    }

    public float getTaxa() {
        return taxa;
    }

    public void setTaxa(float taxa) {
        this.taxa = taxa;
    }

    public float getTaxaImportacao() {
        return taxaImportacao;
    }

    public void setTaxaImportacao(float taxaImportacao) {
        this.taxaImportacao = taxaImportacao;
    }

    @Override
    public String toString() {
        return "Importado{"  + "codigo=" + codigo + ",descricao=" + descricao + ", valor=" + valor + ", imposto=" + imposto + ", tipo=" + tipo + ", taxa=" + taxa + ", taxaImportacao=" + taxaImportacao + '}';
    }

}

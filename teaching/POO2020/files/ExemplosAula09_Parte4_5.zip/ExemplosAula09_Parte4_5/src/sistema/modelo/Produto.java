/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.modelo;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Danilo
 */
public abstract class Produto implements Cloneable{
    protected String codigo;
    protected String descricao;
    protected float valor;
    protected float imposto;
    protected String tipo;

    public Produto() {
    }

    public Produto(String codigo, String descricao, float valor, float imposto) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.valor = valor;
        this.imposto = imposto;
    }
    
    public abstract float calcularPrecoFinal();

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    
    
    public String getTipo(){
        return this.tipo;
    }
    
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public float getImposto() {
        return imposto;
    }

    public void setImposto(float imposto) {
        this.imposto = imposto;
    }    

    @Override
    public String toString() {
        return "Produto{" + "codigo=" + codigo + ", descricao=" + descricao + ", valor=" + valor +
                ", imposto=" + imposto + ", tipo=" + tipo + '}';
    }
    
    @Override
    public Produto clone(){
        try {
            return (Produto) super.clone();
        } catch (CloneNotSupportedException ex) {
            Logger.getLogger(Produto.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
}

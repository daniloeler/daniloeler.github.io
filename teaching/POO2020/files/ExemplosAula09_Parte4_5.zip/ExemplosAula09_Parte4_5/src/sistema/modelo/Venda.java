/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.modelo;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Venda {

    private int num;
    private String CPF; //CPF do cliente
    private Item itens[];
    private int cont;
    private int qtdItens;

    public Venda( int num, String CPF, int qtdItens) {
        this.CPF = CPF;
        this.num = num;
        this.qtdItens = qtdItens;
        this.cont = cont;
        itens = new Item[qtdItens];
    }

    public void addItem(int numero, String codProduto, float valor, float quant) {
        if (cont < qtdItens) {
            itens[cont] = new Item(numero, codProduto, valor, quant);
            cont++;
        }
    }
    

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public Item[] getItens() {
        return itens;
    }

    public int getCont() {
        return cont;
    }

    public int getQtdItens() {
        return qtdItens;
    }
    
}

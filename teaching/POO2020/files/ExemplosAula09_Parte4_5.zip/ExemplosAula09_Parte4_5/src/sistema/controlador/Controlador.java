/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.controlador;

import sistema.modelo.Cliente;
import sistema.modelo.Produto;
import sistema.modelo.Empresa;
import sistema.modelo.Venda;

/**
 *
 * @author Danilo
 */
public class Controlador {
    private Empresa e = new Empresa();
    
    public void addProdutoEstadual(String codigo, String nome, float valor, float imposto){
        e.addProdutoEstadual(codigo, nome, valor, imposto);
    }
    
    public void addProdutoNacional(String codigo, String nome, float valor, float imposto, float taxa){
        e.addProdutoNacional(codigo, nome, valor, imposto, taxa);
    }
    
    public void addProdutoImportado(String codigo, String nome, float valor, float imposto, float taxa, float taxaImp){
       e.addProdutoImportado(codigo, nome, valor, imposto, taxa, taxaImp);
    }
    
     public void addCliente(String nome, String CPF, int idade){
         e.addCliente(nome, CPF, idade);
     }
    
    public String dadosProdutosEstaduais(){
        return e.dadosProdutosEstaduais();
    }
    
    public String dadosProdutosNacionais(){
        return e.dadosProdutosNacionais();
    }
    
    public String dadosProdutosImportados(){
        return e.dadosProdutosImportados();
    }
    
    public Produto buscarProdutoPorNome(String descricao){
        return e.buscarProdutoPorNome(descricao);
    }
    
    public Produto buscarProdutoPorCodigo(String codigo){
        return e.buscarProdutoPorCodigo(codigo);
    }
    
    public Cliente buscarClientePorCPF(String CPF){
        return e.buscarClientePorCPF(CPF);
    }
    
    public Venda buscarVendaPorNum(int num){
        return e.buscarVendaPorNum(num);
    }
    
    public Cliente[] getClientes(){
        return e.getClientes();
    }
    
    public Produto[] getProdutos(){
        return e.getProdutos();
    }
    
    public void novaVenda(int num, String CPF, int qtdItens){
        e.novaVenda(num, CPF, qtdItens);
    }
    
    public void addItem(int numero, String codProduto, float valor, float quant){
        e.addItem(numero, codProduto, valor, quant);
    }
    
    public void gravarVenda(){
        e.gravarVenda();
    }
}

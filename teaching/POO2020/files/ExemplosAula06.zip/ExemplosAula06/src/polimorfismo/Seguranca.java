/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Seguranca extends Funcionario{
    protected String setor;

    public Seguranca() {
        this.tipo = "Seguranca";
    }

    public Seguranca(String codigo, String nome, String setor) {
        super(codigo, nome);
        this.setor = setor;
        this.tipo = "Seguranca";
    }

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }
    
}

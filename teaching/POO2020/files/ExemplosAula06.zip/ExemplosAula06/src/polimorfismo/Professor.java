/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Professor extends Funcionario{
    protected String titulacao;

    public Professor() {
        this.tipo = "Professor";
    }

    public Professor(String codigo, String nome, String titulacao) {
        super(codigo, nome);
        this.titulacao = titulacao;
        this.tipo = "Professor";
    }
    
    
    
}

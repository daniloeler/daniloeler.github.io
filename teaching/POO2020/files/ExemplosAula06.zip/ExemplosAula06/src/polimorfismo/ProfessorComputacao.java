/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class ProfessorComputacao extends Professor{
    protected String codigoSBC;

    public ProfessorComputacao() {
        this.tipo = "ProfessorComputacao";
    }

    public ProfessorComputacao(String codigo, String nome, String titulacao, String codigoSBC) {
        super(codigo, nome, titulacao);
        this.codigoSBC = codigoSBC;
        this.tipo = "ProfessorComputacao";
    }

    public String getCodigoSBC() {
        return codigoSBC;
    }

    public void setCodigoSBC(String codigoSBC) {
        this.codigoSBC = codigoSBC;
    }
    
    
}

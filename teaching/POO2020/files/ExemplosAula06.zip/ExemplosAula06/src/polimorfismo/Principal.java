/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Principal {

    public static void main(String[] args) {
        Funcionario vetor[] = new Funcionario[100];
        vetor[0] = new Funcionario("1111", "Func 1");
        vetor[1] = new Funcionario("222", "Func 2");
        vetor[2] = new Professor("3333", "Professor 1", "Mestre");
        vetor[3] = new ProfessorComputacao("4444", "Professor Computacao 1", "Doutor", "123456");
        vetor[4] = new Seguranca("555", "Seguranca 1", "Setor 1123");
        int cont = 5;        
        
        System.out.println("TODOS FUNCIONARIOS");
        for (int i = 0; i < cont; i++) {
            System.out.println("Nome: " + vetor[i].getNome());
            ///decomentar para ver erro de casting
            //System.out.println("Codigo SBC: "+((ProfessorComputacao) vetor[i]).getCodigoSBC());
        }
        
        System.out.println("\nPROFESSORES");
        for (int i = 0; i < cont; i++) {
            if (vetor[i] instanceof Professor) {
                System.out.println("Nome: " + vetor[i].getNome());  
            }
        }
        
        System.out.println("\nPROFESSORES COMPUTACAO -- usando instanceof");
        for (int i = 0; i < cont; i++) {
            if (vetor[i] instanceof ProfessorComputacao) {
                System.out.println("Nome: " + vetor[i].getNome());                
            }
        }
        
        System.out.println("\nPROFESSORES COMPUTACAO -- usando getTipo");
        for (int i = 0; i < cont; i++) {
            if (vetor[i].getTipo().equals("ProfessorComputacao")) {
                System.out.println("Nome: " + vetor[i].getNome());
                System.out.println("Codigo SBC: "+((ProfessorComputacao) vetor[i]).getCodigoSBC());
                ProfessorComputacao p = (ProfessorComputacao) vetor[i];
                System.out.println("Codigo SBC: "+p.getCodigoSBC());
            }
        }
        
        System.out.println("\nSEGURANCAS - usando instaceof");
        for (int i = 0; i < cont; i++) {
            if (vetor[i] instanceof Seguranca) {
                System.out.println("Nome: " + vetor[i].getNome());                
                System.out.println("Setor: "+((Seguranca) vetor[i]).getSetor());
            }
        }
        
        System.out.println("\nSEGURANCAS -- usando getTipo");
        for (int i = 0; i < cont; i++) {
            if (vetor[i].getTipo().equals("Seguranca")) {
                System.out.println("Nome: " + vetor[i].getNome());
                System.out.println("Setor: "+((Seguranca) vetor[i]).getSetor());
                Seguranca s = (Seguranca) vetor[i];
                System.out.println("Setor: "+s.getSetor());
            }
        }

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classeabastrata;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Estadual extends Produto{

    public Estadual() {
        super();
    }

    public Estadual(String descricao, double valor, double imposto) {
        super(descricao, valor, imposto);
    }
    
    
    
    public double calcularValor(){
        return valor + valor * imposto / 100;
    }
    
    public void exibir(){
        System.out.println("Descrição:"+descricao);
        System.out.println("Valor: R$"+valor);
        System.out.println("Imposto: "+imposto+"%");
        System.out.println("Valor Final: R$"+calcularValor());
    }
}

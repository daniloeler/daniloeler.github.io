/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc01;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Peca {
    protected String nome;
    protected float custo;
    protected float lucro;

    public Peca() {
        custo = 0;
        lucro = 10.0f;
    }

    public Peca(String nome, float custo, float lucro) {
        this.nome = nome;
        this.custo = custo;
        this.lucro = lucro;
    }
    
    public float calcularPreco(){
        return custo + custo * lucro / 100.0f;
    }

    public void exibir(){
        System.out.println("Nome da Peça: "+nome);
        System.out.println("Custo da Peça: R$ "+custo);
        System.out.println("Lucro da Peça: "+lucro+"%");
        System.out.println("Valor final da Peça: R$ "+calcularPreco());
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getCusto() {
        return custo;
    }

    public void setCusto(float custo) {
        this.custo = custo;
    }

    public float getLucro() {
        return lucro;
    }

    public void setLucro(float lucro) {
        this.lucro = lucro;
    }
    
    

}

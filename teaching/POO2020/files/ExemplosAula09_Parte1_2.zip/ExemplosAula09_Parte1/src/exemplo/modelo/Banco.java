/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo.modelo;

import exemplo.persistencia.DataBase;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Banco {

    private DataBase db = DataBase.getInstance(); //new DataBase();
    private String nome;

    public Banco(String nome) {
        this.nome = nome;
    }

    public void addConta(String numero, String titular, double saldo) {
        Conta c = new Conta(numero, titular, saldo);
        db.addConta(c);
    }

    public void addContaEspecial(String numero, String titular, double saldo, double limite) {
        Conta c = new ContaEspecial(numero, titular, saldo, limite);
        db.addConta(c);
    }

    public String dadosTodasContas() {
        String relatorio = "";
        Conta contas[] = db.getContas();
        int cont = db.getNumContas();
        for (int i = 0; i < cont; i++) {
            relatorio = relatorio + contas[i].dados();
        }
        return relatorio;
    }

    public String dadosTodasContasSimples() {
        String relatorio = "";
        Conta contas[] = db.getContas();
        int cont = db.getNumContas();
        for (int i = 0; i < cont; i++) {
            if (contas[i].getTipo().equals(Constantes.CONTA)) {
                relatorio = relatorio + contas[i].dados();
            }
        }
        return relatorio;
    }

    public String dadosTodasContasEspeciais() {
        String relatorio = "";
        Conta contas[] = db.getContas();
        int cont = db.getNumContas();
        for (int i = 0; i < cont; i++) {
            if (contas[i].getTipo().equals(Constantes.CONTA_ESPECIAL)) {
                relatorio = relatorio + contas[i].dados();
            }
        }
        return relatorio;
    }

    public void sacar(String num, double valor) {
        Conta c = db.buscar(num);
        if (c != null) {
            c.sacar(valor);
        }
    }

    public void depositar(String num, double valor) {
        Conta c = db.buscar(num);
        if (c != null) {
            c.depositar(valor);
        }
    }

    public Conta buscar(String num){
        Conta c = db.buscar(num);
        if (c != null) {
            try {
                return c.clone();
            } catch (CloneNotSupportedException ex) {
                Logger.getLogger(Banco.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return null;
    }
}

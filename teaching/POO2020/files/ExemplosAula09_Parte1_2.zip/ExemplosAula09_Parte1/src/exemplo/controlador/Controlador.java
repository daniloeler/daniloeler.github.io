/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo.controlador;

import exemplo.modelo.Banco;
import exemplo.modelo.Conta;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Controlador {
    private Banco banco = new Banco("Banco POO");
    
    public void addConta(String numero, String titular, double saldo) {
        banco.addConta(numero, titular, saldo);
    }

    public void addContaEspecial(String numero, String titular, double saldo, double limite) {
        banco.addContaEspecial(numero, titular, saldo, limite);
    }
    
    public String dadosTodasContas(){
        return banco.dadosTodasContas();
    }
    
    public String dadosTodasContasSimples(){
        return banco.dadosTodasContasSimples();
    }
    
    public String dadosTodasContasEspeciais(){
        return banco.dadosTodasContasEspeciais();
    }
    
    public void sacar(String num, double valor){
        banco.sacar(num, valor);
    }
    
    public void depositar(String num, double valor){
        banco.depositar(num, valor);
    }
    
    public Conta buscarConta(String num){
        return banco.buscar(num);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo.persistencia;

import exemplo.modelo.Conta;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class DataBase {
    
    private Conta contas[];
    private int MAX = 100;
    private int cont;
    private static DataBase instance = null;
    
    private DataBase() {
        contas = new Conta[MAX];
        cont = 0;
    }
    
    public static DataBase getInstance(){
        if (instance == null){
            instance = new DataBase();
        }
        return instance;
    }

    public Conta[] getContas(){
        return this.contas;
    }
    
    public int getNumContas(){
        return this.cont;
    }
    
    public void addConta(Conta c){
        if (cont < MAX) {            
            contas[cont] = c;
            cont++;
        }
    }
    
    public Conta buscar(String num) {
        for (int i = 0; i < cont; i++) {
            if (contas[i].getNumero().equals(num)) {
                return contas[i];
            }
        }
        return null;
    }

    public Conta buscarTitular(String nome) {
        for (int i = 0; i < cont; i++) {
            if (contas[i].getTitular().equals(nome)) {
                return contas[i];
            }
        }
        return null;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula02;

import java.util.Scanner;

/**
 *
 * @author danilo
 */
public class Principal {  
    
    public static void main(String[] args) {
        int numAlunos;
        float nota;
        double saldo;
        boolean flag;
        
        numAlunos = 30;
        nota = 5.6f;
        saldo = 5.6;
        flag = true; // false;
        /*
         comentario cmo mais 
        de
        uma linha
        */
        float peso = 90.0f;
        float altura = 1.78f;
        float imc = peso / (altura * altura);
        imc = peso / (float) Math.pow(altura, 2);
        
        String nome;
        nome = "Danilo";        
        Float f = 4.3f;
        
        System.out.println(imc);
        System.out.println("IMC: "+imc);
        System.out.printf("IMC: %.2f\n", imc);
        System.out.println("Nome: "+nome+"\nPeso: "+peso+"\nICMC: "+imc);
        
        System.out.println("\n\nCONVERSAO DE TIPO");
        int n1;
        float n2;
        n2 = 10.4f;
        n1 = (int) n2;
        float n3 = n1;
        
        System.out.println(n1);
        System.out.println(n2);
        System.out.println(n3);
        
        String numero;        
        numero = Integer.toString(n1);
        System.out.println("String int: "+numero );
        numero = Float.toString(n2);
        System.out.println("String float: "+numero);
        
        numero = "15";
        int n4 = Integer.parseInt(numero);
        System.out.println("Numerico da String: "+n4);        
        numero = "15.5";
        System.out.println("Numerico Float da String: "+Float.parseFloat(numero));
        
        
        //vetores e matrizes
        System.out.println("\n\n\nVETOREs e MATRIZES");
        int vetor[];
        vetor = new int[10];
        int vetor2[] = new int[20];
        
        int matriz[][];
        matriz = new int[5][3];
        
        for(int i=0; i<10; i++){
            vetor[i] = i;
        }
        
        for(int i=0; i<vetor.length; i++){
            vetor[i]=i;
        }
        for(int i=0; i<matriz.length;i++){
            for(int j=0; j<matriz[i].length; j++){
                matriz[i][j] = i*j;
            }
        }
        
        System.out.println(vetor);
        System.out.println(matriz);
        
        for(int i=0; i<vetor.length; i++){
            System.out.print(vetor[i]+", ");
        }
        System.out.println("\n\n");
        for(int i=0; i<matriz.length;i++){
            for(int j=0; j<matriz[i].length; j++){
                System.out.print(matriz[i][j]+"  ");
            }
            System.out.println("\n");
        }
        
        System.out.println("\n\n");
        int i=0;
        while (i<vetor.length){
            System.out.println(vetor[i]);
            i++;
        }
        
        i=0;
        do{
            System.out.println(vetor[i]);
            i++;
        }while(i<vetor.length);
        
        ////condicionais
        
        int idade = 10;
        if (idade >=18){
            System.out.println("Maior");
        }
        else{
            System.out.println("Menor");
        }
        
        if (idade<10){
            System.out.println("Infantil");
        }
        else if (idade>=10 && idade<18){
            System.out.println("Juvenil");            
        }
        else{
            System.out.println("Adulto");            
        }
        
        int opcao = 2;
        
        switch(opcao){
            case 1:
                System.out.println("Opt 1");
                break;
            case 2:
                System.out.println("Opt 2");
                break;
            case 3:
                System.out.println("Opt 3");
                break;
            default:
                System.out.println("Opcao Invalida");
                break;
        }
        
        System.out.println("\n\nENTRADA de DADOS");
        Scanner entrada = new Scanner(System.in);
        float nota1, nota2;
        System.out.print("Nota1: ");
        nota1 = entrada.nextFloat();
        System.out.print("Nota2: ");
        nota2 = entrada.nextFloat();
        float media = (nota1+nota2)/2.0f;
        System.out.println("Nota1: "+ nota1);
        System.out.println("Nota2: "+nota2);
        System.out.println("Media: "+media);
        entrada.nextLine();
        System.out.print("Nome: ");
        nome = entrada.nextLine();
        System.out.print("Idade: ");
        idade = entrada.nextInt();
        
        System.out.println("Nome: "+ nome+ " Idade: "+idade);
        
        
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc03;

import java.util.Scanner;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class SistemaUniversidade {

    private int menu() {
        int op;
        String menu = "MENU DE OPÇÕES\n"
                + "1 – Cadastrar Departamento\n"
                + "2 – Cadastrar Funcionário Técnico\n"
                + "3 – Cadastrar Funcionário Docente\n"
                + "4 – Buscar Departamento por Nome\n"
                + "5 – Buscar Funcionário por Nome\n"
                + "6 – Listar Departamentos com Funcionários com Faixa Salarial Específica\n"
                + "7 – Listar Funcionários com Faixa Salarial Específica\n"
                + "8 – Listar Departamentos cujo gasto total está entre uma Faixa de Valores Específica\n"
                + "9 – Listar todos Funcionários da Universidade\n"
                + "10 – Listar todos Departamentos da Universidade\n"
                + "11 – Listar todos Departamentos da Universidade e seus Respectivos Funcionários\n"
                + "12 – Listar todos Funcionários Docente\n"
                + "13 – Listar todos Funcionários Técnico\n"
                + "0 – Sair";
        System.out.println(menu);
        System.out.print("Digite Opção:");
        Scanner sc = new Scanner(System.in);
        op = Integer.parseInt(sc.nextLine());
        return op;
    }

    public void executar() {
        int op;
        String codigo, nome, nivel, titulacao;
        double salario;
        Scanner sc = new Scanner(System.in);
        Universidade univ = new Universidade("UNESP");
        Departamento depto;
        Tecnico tec;
        Docente doc;
        Funcionario func;
        double ini, fin;
        do {
            op = menu();
            switch (op) {
                case 1:
                    System.out.print("Codigo do Departamento: ");
                    codigo = sc.nextLine();
                    System.out.print("Nome do Departamento: ");
                    nome = sc.nextLine();
                    depto = new Departamento(codigo, nome);
                    univ.addDepartamento(depto);
                    break;
                case 2:
                    System.out.print("Codigo do Departamento: ");
                    codigo = sc.nextLine();
                    depto = univ.buscarDeptoCod(codigo);

                    if (depto != null) {
                        System.out.print("Codigo do Técnico: ");
                        codigo = sc.nextLine();
                        System.out.print("Nome do Técnico: ");
                        nome = sc.nextLine();
                        System.out.print("Salário: R$ ");
                        salario = Double.parseDouble(sc.nextLine());
                        System.out.print("Nível: ");
                        nivel = sc.nextLine();
                        tec = new Tecnico(codigo, nome, salario, nivel);
                        depto.addFuncionario(tec);
                    }else{
                        System.out.println("Departamento Não Encontrado");
                    }

                    break;
                case 3:
                    System.out.print("Codigo do Departamento: ");
                    codigo = sc.nextLine();
                    depto = univ.buscarDeptoCod(codigo);

                    if (depto != null) {
                        System.out.print("Codigo do Docente: ");
                        codigo = sc.nextLine();
                        System.out.print("Nome do Docente: ");
                        nome = sc.nextLine();
                        System.out.print("Salário: R$ ");
                        salario = Double.parseDouble(sc.nextLine());
                        System.out.print("Titulação: ");
                        titulacao = sc.nextLine();
                        doc = new Docente(codigo, nome, salario, titulacao);
                        depto.addFuncionario(doc);
                    }else{
                        System.out.println("Departamento Não Encontrado");
                    }
                    break;
                case 4:
                    System.out.print("Nome do Departamento: ");
                    nome = sc.nextLine();
                    depto = univ.buscarDeptoNome(nome);
                    if (depto != null){
                        depto.exibir();
                    }else{
                        System.out.println("Departamento não Cadastrado");
                    }
                    break;
                case 5:
                    System.out.print("Nome do Funcionário: ");
                    nome = sc.nextLine();
                    func = univ.buscarFuncNome(nome);
                    if (func != null){
                        func.exibir();
                    }else{
                        System.out.println("Funcionário não Cadastrado");
                    }
                    break;
                case 6:
                    System.out.print("Salário Inicial: ");
                    ini = Double.parseDouble(sc.nextLine());
                    System.out.print("Final Inicial: ");
                    fin = Double.parseDouble(sc.nextLine());
                    univ.deptoFuncFaixaSalario(ini, fin);
                    break;
                case 7:
                    System.out.print("Salário Inicial: ");
                    ini = Double.parseDouble(sc.nextLine());
                    System.out.print("Final Inicial: ");
                    fin = Double.parseDouble(sc.nextLine());
                    univ.funcFaixaSalario(ini, fin);
                    break;
                case 8:
                    System.out.print("Salário Inicial: ");
                    ini = Double.parseDouble(sc.nextLine());
                    System.out.print("Final Inicial: ");
                    fin = Double.parseDouble(sc.nextLine());
                    univ.deptoGastoTotal(ini, fin);
                    break;
                case 9:
                    univ.exibirFuncionarios();
                    break;
                case 10:
                    univ.exibirDepartamentos();
                    break;
                case 11:
                    univ.exibir();
                    break;
                case 12:
                    univ.exibirDocentes();
                    break;
                case 13:
                    univ.exibirTecnicos();
                    break;
            }
        } while (op != 0);
    }
}

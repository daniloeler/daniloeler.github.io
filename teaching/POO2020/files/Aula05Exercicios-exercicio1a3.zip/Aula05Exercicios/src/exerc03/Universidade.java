/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc03;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Universidade {
    private String nome;
    private Departamento departamentos[];
    private int cont;
    private int MAX;
    public Universidade(String nome){
        this.nome = nome;
        cont = 0;
        MAX = 1000;
        departamentos = new Departamento[MAX];
    }
    
    public Departamento buscarDeptoNome(String nome){
        for (int i = 0; i < cont; i++) {
            if (departamentos[i].getNome().equals(nome)){
                return departamentos[i];
            }
        }
        return null;
    }
    
    public void deptoFuncFaixaSalario(double ini, double fin){
        for (int i = 0; i < cont; i++) {
            if (departamentos[i].deptoFuncFaixaSalario(ini, fin)){
                System.out.println("  -- "+departamentos[i].getNome());
            }
        }
    }
    
    public void exibirDepartamentos(){
        for (int i = 0; i < cont; i++) {
            System.out.println(" -- Cod: "+departamentos[i].getCodigo()
                    +" Nome: "+departamentos[i].getNome());
        }
    }
    
    public void exibirFuncionarios(){
        for (int i = 0; i < cont; i++) {
            departamentos[i].exibirFuncionarios();
        }
    }
    
    public void exibirTecnicos(){
        for (int i = 0; i < cont; i++) {
            departamentos[i].exibirTecnicos();
        }
    }
    
    public void exibirDocentes(){
        for (int i = 0; i < cont; i++) {
            departamentos[i].exibirDocentes();
        }
    }
    
    public void deptoGastoTotal(double ini, double fin){
        for(int i=0; i<cont; i++){
            double gasto = departamentos[i].gastoTotal();
            if (ini<=gasto && gasto<=fin){
                System.out.println("  --- "+departamentos[i].getNome());
            }
        }
    }
    
    public void funcFaixaSalario(double ini, double fin){
        for(int i=0; i<cont; i++){
            departamentos[i].funcFaixaSalario(ini, fin);
        }
    }
    
    public Funcionario buscarFuncNome(String nome){
        Funcionario f = null;
        for (int i = 0; i < cont; i++) {
            f = departamentos[i].buscarFuncNome(nome);
            if (f!=null){
                return f;
            }
        }
        return null;
    }
    
    public Departamento buscarDeptoCod(String cod){
        for(int i=0; i<cont; i++){
            if (departamentos[i].getCodigo().equals(cod)){
                return departamentos[i];
            }
        }
        return null;
    }
    
    public void exibir(){
        System.out.println("Universidade: "+nome);
        System.out.println("Quantidade de Departamentos: "+cont);
        for(int i=0; i<cont; i++){
            departamentos[i].exibir();
            System.out.println("");
        }
    }
    
    public void addDepartamento(Departamento d){
        if (cont < MAX){
            departamentos[cont] = d;
            cont++;
        }
    }

    public int getQtdDepartamentos(){
        return cont;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Importado extends Produto{
    protected double taxa;
    protected double taxaImportacao;
    
    public Importado(){
        super();
        taxa = 5;
        taxaImportacao = 5;
    }

    public Importado(String descricao, double valor, double imposto, double taxa, double taxaImportacao) {
        super(descricao, valor, imposto);
        this.taxa = taxa;
        this.taxaImportacao = taxaImportacao;
    }
    
    public double valorFinal(){        
        return super.valorFinal() + valor * taxa /100 + valor * taxaImportacao /100;
    }
    
    @Override
    public void exibir(){
        System.out.println("Descrição: "+descricao);
        System.out.println("Valor: R$ "+valor);
        System.out.println("Imposto: "+imposto+"%");
        System.out.println("Taxa: "+taxa+"%");
        System.out.println("Taxa Importação: "+taxaImportacao+"%");
        System.out.println("Valor Final: R$ "+valorFinal());        
    }

    public double getTaxa() {
        return taxa;
    }

    public void setTaxa(double taxa) {
        this.taxa = taxa;
    }

    public double getTaxaImportacao() {
        return taxaImportacao;
    }

    public void setTaxaImportacao(double taxaImportacao) {
        this.taxaImportacao = taxaImportacao;
    }

    
    
}

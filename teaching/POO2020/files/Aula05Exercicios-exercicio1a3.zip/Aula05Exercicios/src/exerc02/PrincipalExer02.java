/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class PrincipalExer02 {
    public static void main(String[] args) {
//        Estadual e = new Estadual("E1",100,10);
//        e.exibir();
//        Nacional n = new Nacional("N1", 100, 10, 5);
//        n.exibir();
//        Importado i = new Importado("I1", 100, 10, 5, 5);
//        i.exibir();
        
        SistemaProdutos sp = new SistemaProdutos();
        sp.executar();
    }
}

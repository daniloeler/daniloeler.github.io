/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc01;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class PecaImportada extends Peca{
    protected float taxaImportacao;
    protected float taxaFrete;

    public PecaImportada() {
        super();
        taxaImportacao = 10;
        taxaFrete = 10;
    }

    public PecaImportada(String nome, float custo, float lucro, float taxaImportacao, float taxaFrete) {
        super(nome, custo, lucro);
        this.taxaImportacao = taxaImportacao;
        this.taxaFrete = taxaFrete;
    }

    @Override
    public float calcularPreco() {           
        //float valorBase = custo + custo *  lucro / 100;
        float valorBase = super.calcularPreco();
        return valorBase + valorBase * taxaImportacao / 100.0f + valorBase * taxaFrete / 100.0f;
    }

    
    public void exibir(){        
        System.out.println("Nome da Peça: "+nome);
        System.out.println("Custo da Peça: R$ "+custo);
        System.out.println("Lucro da Peça: "+lucro+"%");
        System.out.println("Valor Base: R$ "+ (custo + custo * lucro /100));
        System.out.println("Taxa de Importação da Peça: "+taxaImportacao+"%");
        System.out.println("Taxa de Frete da Peça: "+taxaFrete+"%");
        System.out.println("Valor final da Peça: R$ "+calcularPreco());
    }
    
    

    public float getTaxaImportacao() {
        return taxaImportacao;
    }

    public void setTaxaImportacao(float taxaImportacao) {
        this.taxaImportacao = taxaImportacao;
    }

    public float getTaxaFrete() {
        return taxaFrete;
    }

    public void setTaxaFrete(float taxaFrete) {
        this.taxaFrete = taxaFrete;
    }
    
}

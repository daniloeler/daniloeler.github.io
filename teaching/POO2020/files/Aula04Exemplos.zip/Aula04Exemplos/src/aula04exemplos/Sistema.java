/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04exemplos;

import java.util.Scanner;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Sistema {
    private int MAX = 100;
    private Aluno alunos[];
    private int cont;

    public int menu() {
        String menu = "MENU\n"
                + "1 - Cadastar Aluno\n"
                + "2 - Exibir Alunos\n"
                + "3 - Buscar por Nome\n"
                + "9 - Sair\n"
                + "Digite opção: ";
        System.out.println(menu);
        Scanner sc = new Scanner(System.in);
        int op = Integer.parseInt(sc.nextLine());
        return op;
    }
    
    private Aluno buscar(String nome){
        for (int i=0; i<cont; i++){
            if (alunos[i].getNome().equals(nome)){
                return alunos[i];
            }
        }
        return null;
    }

    public void executar() {
        System.out.println("SISTEMA CADASTRO ALUNOS");
        int op;
        Scanner sc = new Scanner(System.in);
        String nome;
        float n1, n2;
        alunos = new Aluno[MAX];
        cont = 0;
        do {
            op = menu();
            switch (op) {
                case 1://cadastro
                    if (cont < MAX) {
                        System.out.print("Nome do Aluno: ");
                        nome = sc.nextLine();
                        System.out.print("Nota 1: ");
                        n1 = Float.parseFloat(sc.nextLine());
                        System.out.print("Nota 2: ");
                        n2 = Float.parseFloat(sc.nextLine());
                        alunos[cont] = new Aluno(nome, n1, n2);
                        cont++;
                    } else {
                        System.out.println("SEM ESPAÇO");
                    }
                    break;
                case 2://exibir
                    for (int i = 0; i < cont; i++) {
                        System.out.println("Nome: " + alunos[i].getNome());
                        System.out.println("Nota 1: " + alunos[i].getN1());
                        System.out.println("Nota 2: " + alunos[i].getN2());
                        System.out.println("Media: " + alunos[i].media());
                        if (alunos[i].aprovado()) {
                            System.out.println("   APROVADO   ");
                        } else {
                            System.out.println("   REPROVADO   ");
                        }
                    }
                    break;
                case 3://consulta
                    System.out.println("Nome do Aluno para consulta: ");
                    nome = sc.nextLine();
                    
                    Aluno a = buscar(nome);
                    if (a!=null){
                        System.out.println("Nome: "+a.getNome());
                        System.out.println("Nota 1: "+a.getN1());
                        System.out.println("Nota 2: "+a.getN2());
                        if (a.aprovado()){
                            System.out.println("APROVADO");
                        }else{
                            System.out.println("REPROVADO");
                        }
                    }else{
                        System.out.println("ALUNO NÃO ENCONTRADO");
                    }
                    
                    
//                    for (int i = 0; i < cont; i++) {
//                        if (alunos[i].getNome().equals(nome)) {
//                            System.out.println("Nome: " + alunos[i].getNome());
//                            System.out.println("Nota 1: " + alunos[i].getN1());
//                            System.out.println("Nota 2: " + alunos[i].getN2());
//                            System.out.println("Media: " + alunos[i].media());
//                            if (alunos[i].aprovado()) {
//                                System.out.println("   APROVADO   ");
//                            } else {
//                                System.out.println("   REPROVADO   ");
//                            }
//                        }
//                    }
                    break;
            }
        } while (op != 9);

    }
}

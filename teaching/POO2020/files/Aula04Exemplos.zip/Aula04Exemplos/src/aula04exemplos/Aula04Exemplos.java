/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04exemplos;

import java.util.Scanner;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Aula04Exemplos {

    public static void main(String[] args) {
        Aluno vetor[] = new Aluno[5];
        vetor[0] = new Aluno();
        vetor[0].setN1(9);
        vetor[0].setN2(10);
        vetor[1] = new Aluno("Aluno 2", 5, 3);

        System.out.println("Media: " + vetor[0].media());
        System.out.println("Aprovado: " + vetor[0].aprovado());
        if (vetor[0].aprovado()) {
            System.out.println("Aprovado");
        } else {
            System.out.println("Reprovado");
        }

        System.out.println("\nPERCORRENDO O VETOR\n");
        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] != null) {
                System.out.println("Media: " + vetor[i].media());
                System.out.println("Aprovado: " + vetor[i].aprovado());
                if (vetor[i].aprovado()) {
                    System.out.println("Aprovado");
                } else {
                    System.out.println("Reprovado");
                }
            }
        }
        int cont = 2;
        System.out.println("\nPERCORRENDO O VETOR\n");
        for (int i = 0; i < cont; i++) {
            System.out.println("Media: " + vetor[i].media());
            System.out.println("Aprovado: " + vetor[i].aprovado());
            if (vetor[i].aprovado()) {
                System.out.println("Aprovado");
            } else {
                System.out.println("Reprovado");
            }
        }
    }
}

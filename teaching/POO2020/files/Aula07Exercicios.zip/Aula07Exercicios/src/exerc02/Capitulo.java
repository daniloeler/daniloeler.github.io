/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Capitulo {
    private static int numAtual = 0;
    private int num;
    private String nome;
    private int paginas;

    public Capitulo(String nome, int paginas) {
        this.nome = nome;
        this.paginas = paginas;
        numAtual++;
        this.num = numAtual;        
    }
    
    public void exibir(){
        System.out.println("Capítulo: "+num);
        System.out.println("Título: "+nome);
        System.out.println("Num. Páginas: "+paginas);
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }
    
}

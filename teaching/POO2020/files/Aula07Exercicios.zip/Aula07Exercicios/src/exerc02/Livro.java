/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Livro {
     private String isbn;
     private String titulo;
     private int qtdCap;
     private Capitulo capitulos[];
     private int cont;
    public Livro(String isbn, String titulo, int qtdCap) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.qtdCap = qtdCap;
        cont = 0;
        capitulos = new Capitulo[qtdCap];
    }
    
    public void addCapitulo(Capitulo c){
        if (cont < qtdCap){
            capitulos[cont] = c;
            cont++;
        }
    }
    
    public void exibir(){
        System.out.println("Editora: "+ Constantes.EDITORA);
        System.out.println("Livro: "+titulo);
        System.out.println("ISBN: "+isbn);
        System.out.println("Número de Capítulos: "+ qtdCap);
        for (int i = 0; i < cont; i++) {
            capitulos[i].exibir();
        }
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getQtdCap() {
        return qtdCap;
    }

    public void setQtdCap(int qtdCap) {
        this.qtdCap = qtdCap;
    }
    
    
     
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc02;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Principal {
    public static void main(String[] args) {
       Livro l = new Livro("2163564654", "Livro 1", 3);
       l.addCapitulo(new Capitulo("Capitulo 1", 10));
       l.addCapitulo(new Capitulo("Capitulo 2", 11));
       l.addCapitulo(new Capitulo("Capitulo 3", 20));
       l.exibir();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc01;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Principal {
    public static void main(String[] args) {
        float vetor[] = {2, 1, 5, 4, 3};
        System.out.println("Média: "+Utilidade.media(vetor));
        System.out.println("Soma: "+Utilidade.soma(vetor));
        System.out.println("Maior: "+ Utilidade.maior(vetor));
        System.out.println("Menor: " + Utilidade.menor(vetor));
        System.out.println("Max (4, 7): "+Utilidade.max(4, 7));
        System.out.println("Max (7, 4): "+Utilidade.max(7, 4));        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerc01;

/**
 *
 * @author Danilo Medeiros Eler (FCT-UNESP) - https://daniloeler.github.io/
 */
public class Utilidade {
    //calcula a media dos elementos do vetor
    public static float media(float vet[]) {
        float soma = 0;
        for (int i = 0; i < vet.length; i++) {
            soma = soma + vet[i];
        }
        return soma / vet.length;
    }
    
    //calcula a soma dos elementos do vetor
    public static float soma(float vet[]) {
        float soma = 0;
        for (int i = 0; i < vet.length; i++) {
            soma = soma + vet[i];
        }
        return soma;
    }

    //encontra o maior dos elementos do vetor
    public static float maior(float vet[]) {
        float maior = vet[0];
        for (int i = 1; i < vet.length; i++) {
            if (maior < vet[i]) {
                maior = vet[i];
            }
        }
        return maior;
    }

    //encontra o menor dos elementos do vetor
    public static float menor(float vet[]) {
        float menor = vet[0];
        for (int i = 1; i < vet.length; i++) {
            if (menor > vet[i]) {
                menor = vet[i];
            }
        }
        return menor;
    }

    //retorna o maior elemento da comparação entre A e B
    public static int max(int A, int B) {
        if (A > B){
            return A;
        }
        return B;
    }
}
